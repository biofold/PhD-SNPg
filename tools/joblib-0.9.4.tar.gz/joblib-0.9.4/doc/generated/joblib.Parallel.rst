joblib.Parallel
===============

.. currentmodule:: joblib

.. autoclass:: Parallel
