joblib.Memory
=============

.. currentmodule:: joblib

.. autoclass:: Memory
